//
//  JFrogSDK.h
//  JFrogSDK
//
//  Created by Ashish Awasthi on 08/09/22.
//

#import <Foundation/Foundation.h>

//! Project version number for JFrogSDK.
FOUNDATION_EXPORT double JFrogSDKVersionNumber;

//! Project version string for JFrogSDK.
FOUNDATION_EXPORT const unsigned char JFrogSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JFrogSDK/PublicHeader.h>


